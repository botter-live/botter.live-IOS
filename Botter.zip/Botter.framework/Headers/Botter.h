//
//  BotterSDK.h
//  BotterSDK
//
//  Created by Nora on 6/7/20.
//  Copyright © 2020 BlueCrunch. All rights reserved.
//

#import <Foundation/Foundation.h>
//#import "UIView+WebCache.h"
//#import "UIButton+WebCache.h"
//#import "UIImageView+WebCache.h"

//! Project version number for BotterSDK.
FOUNDATION_EXPORT double BotterSDKVersionNumber;

//! Project version string for BotterSDK.
FOUNDATION_EXPORT const unsigned char BotterSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BotterSDK/PublicHeader.h>


